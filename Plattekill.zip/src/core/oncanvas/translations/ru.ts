export default {
	'Menu': 'Меню'
};