export default {
	'Menu': 'Menü'
};