export default {
	'Menu': 'Menu'
};