export default {
	'Menu': 'منو'
};
