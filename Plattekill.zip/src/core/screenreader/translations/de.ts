export default {
    'Close menu': 'Menü schließen',
    'Close submenu': 'Untermenü schließen',
    'Open submenu': 'Untermenü öffnen',
    'Toggle submenu': 'Untermenü wechseln'
};
