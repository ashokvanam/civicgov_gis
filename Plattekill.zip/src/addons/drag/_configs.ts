const configs : mmConfigsDrag = {
	menu: {
		width: {
			perc: 0.8,
			min: 140,
			max: 440
		},
		height: {
			perc: 0.8,
			min: 140,
			max: 880
		}
	}
};
export default configs;