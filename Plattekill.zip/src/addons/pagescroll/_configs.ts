const configs: mmConfigsPagescroll = {
    updateOffset: 50
};
export default configs;
