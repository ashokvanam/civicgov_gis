const configs : mmConfigsFixedelements = {
	fixed: {
		insertMethod: 'append',
		insertSelector: 'body'
	},
	sticky: {
		offset : 0
	}
};
export default configs;